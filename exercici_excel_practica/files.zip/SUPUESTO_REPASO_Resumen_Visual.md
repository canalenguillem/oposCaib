# SUPUESTO REPASO: RESUMEN VISUAL

---

## ESTRUCTURA GENERAL DEL ARCHIVO

```
EXCEL WORKBOOK: supuesto_repaso_excel_BASE.xlsx
│
├─ HOJA 1: PRODUCTOS ════════════════════════════════════════════
│  │
│  └─ TABLA_PRODUCTOS (tabla formal)
│     ├─ A: CÓDIGO (P001-P008)
│     ├─ B: DESCRIPCIÓN (nombres productos)
│     ├─ C: CATEGORÍA (Monitores, Periféricos, etc.)
│     ├─ D: PRECIO_UNITARIO (€ 8,00 a € 320,00)
│     └─ E: STOCK (unidades disponibles)
│
├─ HOJA 2: VENTAS_DIARIAS ═══════════════════════════════════════
│  │
│  └─ TABLA_VENTAS (tabla formal, 40 registros)
│     ├─ A: FECHA (01/06/2025 a 15/06/2025)
│     ├─ B: CÓDIGO_PRODUCTO (P001-P008 aleatorio)
│     ├─ C: CANTIDAD (1-10 aleatorio)
│     ├─ D: VENDEDOR (Juan, María, Carlos, Ana, Roberto)
│     └─ E: REGIÓN (Islas Baleares, Cataluña, Valencia, Andalucía)
│
├─ HOJA 3: ANÁLISIS ═════════════════════════════════════════════
│  │
│  ├─ SECCIÓN 1: Análisis de Productos (filas 1-9)
│  │  │
│  │  └─ Tabla:
│  │     ┌─────────────────────────────────────────────────────┐
│  │     │ A: Código │ B: Desc │ C: Precio │ D: Total │ E: Desc │ F: Precio Final │
│  │     ├─────────────────────────────────────────────────────┤
│  │     │ P001      │ <VL>    │ <VL>      │ <Sum>    │ <IF>    │ <ROUND>         │
│  │     │ P003      │ <VL>    │ <VL>      │ <Sum>    │ <IF>    │ <ROUND>         │
│  │     │ P005      │ <VL>    │ <VL>      │ <Sum>    │ <IF>    │ <ROUND>         │
│  │     │ P007      │ <VL>    │ <VL>      │ <Sum>    │ <IF>    │ <ROUND>         │
│  │     └─────────────────────────────────────────────────────┘
│  │
│  └─ SECCIÓN 2: Estadísticas (filas 11-24)
│     ├─ B13: Total de ventas (€)
│     ├─ B14: Número de transacciones
│     ├─ B15: Cantidad promedio por venta
│     ├─ B16: Cantidad máxima
│     ├─ B17: Cantidad mínima
│     └─ B20:B23: Ventas por región
│
├─ HOJA 4: TABLA_DINÁMICA ══════════════════════════════════════
│  │
│  └─ Tabla de Resumen (5 × 4 matrix)
│     ┌────────────────────────────────────────────────────┐
│     │ Vendedor │ Islas Bal │ Cataluña │ Valencia │ Andul │ Total│
│     ├────────────────────────────────────────────────────┤
│     │ Juan     │ <SUMP>    │ <SUMP>   │ <SUMP>   │ <SMP> │ <SUM>│
│     │ María    │ <SUMP>    │ <SUMP>   │ <SUMP>   │ <SMP> │ <SUM>│
│     │ Carlos   │ <SUMP>    │ <SUMP>   │ <SUMP>   │ <SMP> │ <SUM>│
│     │ Ana      │ <SUMP>    │ <SUMP>   │ <SUMP>   │ <SMP> │ <SUM>│
│     │ Roberto  │ <SUMP>    │ <SUMP>   │ <SUMP>   │ <SMP> │ <SUM>│
│     ├────────────────────────────────────────────────────┤
│     │ TOTAL    │ <SUM>     │ <SUM>    │ <SUM>    │ <SUM> │ 40   │
│     └────────────────────────────────────────────────────┘
│
└─ HOJA 5: GRÁFICO_VENTAS ══════════════════════════════════════
   │
   ├─ Datos: A3:B8 (Vendedor + Total)
   │
   └─ Gráfico: Columnas Agrupadas
      ┌─────────────────────────────────────────┐
      │ Cantidad Total Vendida por Vendedor     │
      │ (Junio 2025)                            │
      │                                         │
      │   8 ┃  ┌─┐  ┌─┐  ┌─┐  ┌─┐  ┌─┐         │
      │   7 ┃  │ │  │ │  │ │  │ │  │ │         │
      │   6 ┃  │ │  │ │  │ │  │ │  │ │         │
      │   5 ┃  │ │  │ │  │ │  │ │  │ │         │
      │   4 ┃  │ │  │ │  │ │  │ │  │ │         │
      │   3 ┃  │ │  │ │  │ │  │ │  │ │         │
      │   2 ┃  │ │  │ │  │ │  │ │  │ │         │
      │   1 ┃  │ │  │ │  │ │  │ │  │ │         │
      │   0 ┃──┴─┴──┴─┴──┴─┴──┴─┴──┴─┴─────────│
      │      Juan Mar Car Ana Rob                 │
      └─────────────────────────────────────────┘
```

---

## FLUJO DE DATOS (Data Flow)

```
                    ┌──────────────────────┐
                    │   TABLA_PRODUCTOS    │
                    │  (8 productos base)  │
                    │  P001-P008           │
                    │  Precio: €8-€320     │
                    └──────────┬───────────┘
                               │
                 ┌─────────────┘└─────────────┐
                 │                           │
                 ▼                           ▼
    ┌─────────────────────┐      ┌──────────────────────┐
    │ VLOOKUP Descripción │      │ VLOOKUP Precio Unit. │
    │      B4:B7          │      │      C4:C7           │
    └──────────┬──────────┘      └──────────┬───────────┘
               │                            │
               └────────────┬───────────────┘
                            ▼
                ┌──────────────────────────┐
                │   TABLA_VENTAS           │
                │  (40 transacciones)      │
                │  Cantidad, Vendedor,     │
                │  Región, Código Producto │
                └────┬────────────────┬────┘
                     │                │
        ┌────────────┘                └──────────────┐
        │                                            │
        ▼                                            ▼
    ┌──────────────────────┐           ┌───────────────────────┐
    │ SUMPRODUCT           │           │ TABLA_DINÁMICA        │
    │ Total x Producto     │           │ Vendedor × Región     │
    │ (D4:D7)              │           │ (SUMPRODUCT)          │
    └─────────┬────────────┘           └───────────┬───────────┘
              │                                     │
              ▼                                     ▼
    ┌──────────────────────┐           ┌───────────────────────┐
    │ IF Anidado Descuento │           │ GRÁFICO: Columnas     │
    │ (E4:E7)              │           │ (Vendedor × Cantidad) │
    └─────────┬────────────┘           └───────────────────────┘
              │
              ▼
    ┌──────────────────────┐
    │ ROUND Precio Final   │
    │ (F4:F7)              │
    └─────────┬────────────┘
              │
              ▼
    ┌──────────────────────┐
    │ ANÁLISIS COMPLETADO  │
    └──────────────────────┘
```

---

## SECCIÓN 1: ANÁLISIS DE PRODUCTOS (VISUAL)

### Tabla de Análisis

```
┌──────────┬──────────────────────┬──────────┬──────────────┬────────────┬──────────────────┐
│    A     │          B           │    C     │      D       │     E      │        F         │
│  CÓDIGO  │    DESCRIPCIÓN       │ PRECIO U │  TOTAL VND  │ DESCUENTO  │  PRECIO FINAL    │
├──────────┼──────────────────────┼──────────┼──────────────┼────────────┼──────────────────┤
│   P001   │  Monitor LED 24"     │ € 150,00 │ € 1.050,00   │    10%     │  € 945,00        │
│  (VLOOK)│ (=VLOOKUP A4...)     │(=VLOOK..)|=(SUMPRODUCT) │ (=IF...)   │ (=ROUND(...,2))  │
├──────────┼──────────────────────┼──────────┼──────────────┼────────────┼──────────────────┤
│   P003   │  Ratón Inalámbrico   │ € 35,00  │ € 665,00     │    10%     │  € 598,50        │
├──────────┼──────────────────────┼──────────┼──────────────┼────────────┼──────────────────┤
│   P005   │  SSD 500GB           │ € 55,00  │ € 935,00     │    10%     │  € 841,50        │
├──────────┼──────────────────────┼──────────┼──────────────┼────────────┼──────────────────┤
│   P007   │  Memoria RAM 16GB    │ € 95,00  │ € 1.235,00   │    10%     │ € 1.111,50       │
└──────────┴──────────────────────┴──────────┴──────────────┴────────────┴──────────────────┘

COLORES DE FORMATO:
- Encabezado (A3:F3): Azul 4472C4, texto blanco
- Moneda (C4:C7, D4:D7, F4:F7): Formato "€ "#.##0,00
- Porcentaje (E4:E7): Formato 0"%"
```

### Fórmula Detallada: B4 (VLOOKUP)

```
=VLOOKUP(A4, TABLA_PRODUCTOS, 2, 0)

Desglose:
┌──────────────────────────────────┐
│ A4 = "P001" (lo que buscamos)    │
│ TABLA_PRODUCTOS = dónde buscamos │
│ 2 = columna a devolver           │
│ 0 = búsqueda EXACTA              │
└──────────────────────────────────┘

Resultado: "Monitor LED 24""
```

### Fórmula Detallada: D4 (SUMPRODUCT)

```
=SUMPRODUCT((TABLA_VENTAS[CÓDIGO_PRODUCTO]=A4)*(TABLA_VENTAS[CANTIDAD]))*C4

Desglose:
┌────────────────────────────────────────────────────────────┐
│ (TABLA_VENTAS[CÓDIGO_PRODUCTO]=A4)                         │
│    → Busca todas las filas donde código = P001             │
│    → Devuelve: TRUE, TRUE, FALSE, TRUE, ... (matriz booleana)
│                                                            │
│ * (TABLA_VENTAS[CANTIDAD])                                 │
│    → Multiplica cantidad × booleano (1 si TRUE, 0 si FALSE)
│    → Suma solo cantidades de P001                          │
│    → Resultado: 7 unidades                                 │
│                                                            │
│ * C4                                                       │
│    → Multiplica total unidades × precio (150€)             │
│    → 7 × 150 = 1.050€                                      │
└────────────────────────────────────────────────────────────┘
```

### Fórmula Detallada: E4 (IF Anidado)

```
=IF(D4>500, 10, IF(D4>250, 5, 0))

Árbol de decisión:
                    D4 = 1.050€
                         │
                  ¿D4 > 500€?
                    Sí / No
                    │
          ┌─────────┴────────────┐
          │                      │
         Sí                      No
        (10%)               ¿D4 > 250€?
         │                      │
         │              ┌───────┴────────┐
         │              │                │
         │             Sí                No
         │            (5%)              (0%)
         │
         └─→ RESULTADO: 10

Para D4 = 1.050€ > 500€ → Devuelve 10 (%)
```

### Fórmula Detallada: F4 (ROUND)

```
=ROUND(D4*(1-E4/100), 2)

Cálculo paso a paso:
┌─────────────────────────────────────┐
│ D4 = 1.050€                         │
│ E4 = 10 (%)                         │
│                                     │
│ (1 - E4/100)                        │
│ = 1 - 10/100                        │
│ = 1 - 0,1                           │
│ = 0,9  (multiplicador para 90%)     │
│                                     │
│ D4 * 0,9                            │
│ = 1.050 × 0,9                       │
│ = 945,00000000... (error redondeo)  │
│                                     │
│ ROUND(..., 2)                       │
│ → Redondea a 2 decimales            │
│ = 945,00€ (exacto para dinero)      │
└─────────────────────────────────────┘
```

---

## SECCIÓN 2: ESTADÍSTICAS (VISUAL)

### Tabla de Estadísticas

```
┌────────────────────────────────────────┬──────────────┐
│            DESCRIPCIÓN                 │    VALOR     │
├────────────────────────────────────────┼──────────────┤
│ Total de ventas (€):                   │   € 8.650    │
│ Fórmula: =SUMPRODUCT(...)              │ (variable)   │
├────────────────────────────────────────┼──────────────┤
│ Número de transacciones:               │      40      │
│ Fórmula: =COUNTA(TABLA_VENTAS[...])    │ (fijo)       │
├────────────────────────────────────────┼──────────────┤
│ Cantidad promedio por venta:           │     4,5      │
│ Fórmula: =AVERAGE(TABLA_VENTAS[...])   │ (variable)   │
├────────────────────────────────────────┼──────────────┤
│ Cantidad máxima:                       │      10      │
│ Fórmula: =MAX(TABLA_VENTAS[...])       │ (fijo)       │
├────────────────────────────────────────┼──────────────┤
│ Cantidad mínima:                       │       1      │
│ Fórmula: =MIN(TABLA_VENTAS[...])       │ (fijo)       │
└────────────────────────────────────────┴──────────────┘

COLORES:
- Etiquetas (A13:A17): Fondo gris E2EFDA, texto negrita
```

### Ventas por Región

```
┌──────────────────────┬────────────┐
│      REGIÓN          │ CANTIDAD   │
├──────────────────────┼────────────┤
│ Islas Baleares       │     10     │
│ (=SUMPRODUCT(...))   │            │
├──────────────────────┼────────────┤
│ Cataluña             │     10     │
│ (=SUMPRODUCT(...))   │            │
├──────────────────────┼────────────┤
│ Valencia             │     10     │
│ (=SUMPRODUCT(...))   │            │
├──────────────────────┼────────────┤
│ Andalucía            │     10     │
│ (=SUMPRODUCT(...))   │            │
├──────────────────────┼────────────┤
│ SUMA TOTAL           │     40     │
└──────────────────────┴────────────┘

COLORES:
- Etiquetas (A20:A23): Fondo FFF2CC
- Todos los datos: Centrados
```

---

## SECCIÓN 3: TABLA DINÁMICA (VISUAL)

### Estructura Matriz

```
┌─────────────┬────────────┬──────────┬──────────┬──────────┬────────┐
│  VENDEDOR   │Islas Bal.  │Cataluña  │Valencia  │Andalucía │ TOTAL  │
├─────────────┼────────────┼──────────┼──────────┼──────────┼────────┤
│   Juan      │    2-3     │   2-3    │   2-3    │   2-3    │  8-10  │
│   (A4)      │ =SMP(...)  │=SMP(...) │=SMP(...) │=SMP(...) │=SUM()  │
├─────────────┼────────────┼──────────┼──────────┼──────────┼────────┤
│   María     │    2-3     │   2-3    │   2-3    │   2-3    │  8-10  │
├─────────────┼────────────┼──────────┼──────────┼──────────┼────────┤
│   Carlos    │    2-3     │   2-3    │   2-3    │   2-3    │  8-10  │
├─────────────┼────────────┼──────────┼──────────┼──────────┼────────┤
│   Ana       │    2-3     │   2-3    │   2-3    │   2-3    │  8-10  │
├─────────────┼────────────┼──────────┼──────────┼──────────┼────────┤
│   Roberto   │    2-3     │   2-3    │   2-3    │   2-3    │  8-10  │
├─────────────┼────────────┼──────────┼──────────┼──────────┼────────┤
│   TOTAL     │   10-15    │  10-15   │  10-15   │  10-15   │   40   │
│  (A9)       │ =SUM(...)  │=SUM(...) │=SUM(...) │=SUM(...) │=SUM()  │
└─────────────┴────────────┴──────────┴──────────┴──────────┴────────┘

COLORES:
- Encabezado (fila 3): Azul 5B9BD5, texto blanco
- Total (fila 9): Gris D9E1F2, texto negrita
- Números: Centrados, sin decimales
```

### Ejemplo de Fórmula SUMPRODUCT (B4)

```
=SUMPRODUCT((TABLA_VENTAS[VENDEDOR]=A4)*(TABLA_VENTAS[REGIÓN]="Islas Baleares")*(TABLA_VENTAS[CANTIDAD]))

┌──────────────────────────────────────────────────────────────────┐
│                                                                  │
│ (TABLA_VENTAS[VENDEDOR]=A4)                                      │
│   ↓                                                              │
│   Busca donde VENDEDOR = "Juan"  →  [T,F,T,F,F,T,F,...]        │
│                                                                  │
│ (TABLA_VENTAS[REGIÓN]="Islas Baleares")                          │
│   ↓                                                              │
│   Busca donde REGIÓN = "Islas Baleares"  →  [T,T,F,T,F,F,...]  │
│                                                                  │
│ Combina con AND (multiplicación):                                │
│   [T,F,T,...] × [T,T,F,...] = [T,F,F,...] (solo si ambos TRUE)  │
│                                                                  │
│ (TABLA_VENTAS[CANTIDAD])                                         │
│   ↓                                                              │
│   Valores: [5, 3, 7, 4, 2, 6, 8, ...]                            │
│                                                                  │
│ Multiplicación final:                                            │
│   [1,0,0,...] × [5,3,7,4,2,6,8,...] = [5,0,0,...]               │
│                                                                  │
│ SUM: 5 + 0 + 0 + ... = 5 unidades                                │
│   (O aproximadamente 2-3 en realidad)                            │
│                                                                  │
└──────────────────────────────────────────────────────────────────┘
```

---

## SECCIÓN 4: GRÁFICO (VISUAL)

### Representación ASCII

```
┌────────────────────────────────────────────────────────┐
│   Cantidad Total Vendida por Vendedor (Junio 2025)     │
│                                                        │
│       10 │                                             │
│        9 │     ┌─┐     ┌─┐     ┌─┐     ┌─┐     ┌─┐    │
│        8 │     │ │     │ │     │ │     │ │     │ │    │
│        7 │     │ │     │ │     │ │     │ │     │ │    │
│        6 │     │ │     │ │     │ │     │ │     │ │    │
│        5 │     │ │     │ │     │ │     │ │     │ │    │
│        4 │     │ │     │ │     │ │     │ │     │ │    │
│        3 │     │ │     │ │     │ │     │ │     │ │    │
│        2 │     │ │     │ │     │ │     │ │     │ │    │
│        1 │     │ │     │ │     │ │     │ │     │ │    │
│        0 └─────┴─┴─────┴─┴─────┴─┴─────┴─┴─────┴─┘────│
│          Juan  María  Carlos  Ana  Roberto            │
│                                                        │
│          Eje Y: Cantidad (unidades)                    │
│          Eje X: Vendedor                               │
└────────────────────────────────────────────────────────┘

CARACTERÍSTICAS:
- Tipo: Columnas agrupadas
- Datos: A3:B8 (Vendedor + Total)
- Referencia: =TABLA_DINÁMICA!F4:F8
- 5 barras de altura similar (8-10 cada una)
```

---

## FLUJO DE TRABAJO VISUAL

```
INICIO
  │
  ▼
┌─────────────────────────────┐
│ Abrir archivo BASE.xlsx     │
│ Hoja: ANÁLISIS              │
└──────────────┬──────────────┘
               │
               ▼
        ┌──────────────┐
        │  PASO 1      │
        │ VLOOKUP DESC │
        │ (B4:B7)      │
        └──────┬───────┘
               │
               ▼
        ┌──────────────┐
        │  PASO 2      │
        │ VLOOKUP PREC │
        │ (C4:C7)      │
        │ Formato: €   │
        └──────┬───────┘
               │
               ▼
        ┌──────────────┐
        │  PASO 3      │
        │ SUMPRODUCT   │
        │ (D4:D7)      │
        │ Formato: €   │
        └──────┬───────┘
               │
               ▼
        ┌──────────────┐
        │  PASO 4      │
        │ IF ANIDADO   │
        │ (E4:E7)      │
        │ Formato: %   │
        └──────┬───────┘
               │
               ▼
        ┌──────────────┐
        │  PASO 5      │
        │ ROUND        │
        │ (F4:F7)      │
        │ Formato: €   │
        └──────┬───────┘
               │
               ▼
        ┌──────────────┐
        │  PASO 6      │
        │ESTADÍSTICAS  │
        │ (B13:B23)    │
        └──────┬───────┘
               │
               ▼
        ┌──────────────┐
        │  PASO 7      │
        │  TABLA       │
        │  DINÁMICA    │
        │ (A3:F9)      │
        │ SUMPRODUCT   │
        └──────┬───────┘
               │
               ▼
        ┌──────────────┐
        │  PASO 8      │
        │  GRÁFICO     │
        │  COLUMNAS    │
        │  (5 series)  │
        └──────┬───────┘
               │
               ▼
        ┌──────────────┐
        │  PASO 9      │
        │  FORMATOS &  │
        │  IMPRESIÓN   │
        └──────┬───────┘
               │
               ▼
            FINAL
           ✓ Completado
```

---

## MAPEO DE CELDAS (LOCATION MAP)

### Hoja ANÁLISIS

```
     A              B               C            D           E         F
1    SECCIÓN 1...
2    
3    Código         Descripción     Precio U.    Total V.    Desc.     Precio Final
4    P001          ←VLOOKUP→       ←VLOOKUP→    ←SUMPRODUCT←IF ANIDADO→←ROUND→
5    P003          (B4 fórmula)     (C4 fórmula) (D4 fórmula)(E4)       (F4)
6    P005          (copiar)         (copiar)     (copiar)    (copiar)   (copiar)
7    P007          (B5, B6, B7)     (C5, C6, C7) (D5, D6, D7)(E5, E6, E7)(F5, F6, F7)
8
9
10
11   SECCIÓN 2...
12
13   Total de ventas (€):              ← SUMPRODUCT (B13)
14   Número de transacciones:          ← COUNTA (B14)
15   Cantidad promedio por venta:      ← AVERAGE (B15)
16   Cantidad máxima:                  ← MAX (B16)
17   Cantidad mínima:                  ← MIN (B17)
18
19   Ventas por región:
20   Islas Baleares                    ← SUMPRODUCT (B20)
21   Cataluña                          ← SUMPRODUCT (B21)
22   Valencia                          ← SUMPRODUCT (B22)
23   Andalucía                         ← SUMPRODUCT (B23)
```

### Hoja TABLA_DINÁMICA

```
     A              B            C         D         E         F
1    TABLA DE RESUMEN...
2
3    VENDEDOR   Islas Baleares Cataluña Valencia  Andalucía  Total
4    Juan       ←SUMPRODUCT→  ←SMP→    ←SMP→     ←SMP→      ←SUM→
5    María      (B4)          (C4)     (D4)      (E4)       (F4)
6    Carlos     (copiar →)    (copiar)(copiar)  (copiar)   (copiar)
7    Ana        (B5, B6, etc) (C5...) (D5...)   (E5...)    (F5...)
8    Roberto    (filas)       (todas) (todas)   (todas)    (todas)
9
10   TOTAL      ←SUM→         ←SUM→   ←SUM→     ←SUM→      =40
                 (B4:B8)      (C4:C8) (D4:D8)   (E4:E8)    (F4:F8)
```

### Hoja GRÁFICO_VENTAS

```
     A              B
1    Análisis Visual: Ventas por Vendedor
2
3    VENDEDOR       TOTAL (unidades)
4    Juan           ← =TABLA_DINÁMICA!F4
5    María          ← =TABLA_DINÁMICA!F5
6    Carlos         ← =TABLA_DINÁMICA!F6
7    Ana            ← =TABLA_DINÁMICA!F7
8    Roberto        ← =TABLA_DINÁMICA!F8
9
10   [GRÁFICO DE COLUMNAS AGRUPADAS AQUÍ]
     (A3:B8 como fuente de datos)
```

---

## CHECKLIST VISUAL

### ✓ Fórmulas Completadas

```
APARTADO 1:
☐ B4:B7    [VLOOKUP DESCRIPCIÓN]        ✓ Descripciones aparecen
☐ C4:C7    [VLOOKUP PRECIO]             ✓ Precios con €
☐ D4:D7    [SUMPRODUCT × PRECIO]        ✓ Totales en €
☐ E4:E7    [IF ANIDADO]                 ✓ % (10, 5, 0)
☐ F4:F7    [ROUND 2 DECIMALES]          ✓ Precio final en €

APARTADO 2:
☐ B13      [SUMPRODUCT TOTAL]           ✓ > 8.000€
☐ B14      [COUNTA]                     ✓ = 40
☐ B15      [AVERAGE]                    ✓ ≈ 4,5
☐ B16      [MAX]                        ✓ = 10
☐ B17      [MIN]                        ✓ = 1
☐ B20:B23  [SUMPRODUCT REGIÓN]          ✓ Suma = 40

APARTADO 3:
☐ B4:E8    [SUMPRODUCT]                 ✓ Vendedor × Región
☐ F4:F8    [SUM POR VENDEDOR]           ✓ Totales por vendedor
☐ B9:F9    [SUM POR REGIÓN]             ✓ Totales por región
☐ F9       [TOTAL GENERAL]              ✓ = 40

APARTADO 4:
☐ GRÁFICO  [COLUMNAS AGRUPADAS]         ✓ 5 barras
```

---

## NOTAS PEDAGÓGICAS (VISUAL)

```
┌──────────────────────────────────────────────────────────────┐
│ FUNCIONES CLAVE Y SU PAPEL                                   │
├──────────────────────────────────────────────────────────────┤
│                                                              │
│  VLOOKUP                                                     │
│  ├─ Función: Buscar (no escribir)                            │
│  ├─ Uso: B4, C4 (obtener datos de tabla)                     │
│  └─ Ventaja: Automatización, sin errores manuales            │
│                                                              │
│  SUMPRODUCT                                                  │
│  ├─ Función: Sumar con condiciones múltiples                 │
│  ├─ Uso: D4, B20:B23, TABLA_DINÁMICA                         │
│  └─ Ventaja: Análisis flexible (vendedor × región)           │
│                                                              │
│  IF ANIDADO                                                  │
│  ├─ Función: Lógica de decisión (cascada)                    │
│  ├─ Uso: E4 (descuentos según total)                         │
│  └─ Ventaja: Implementa reglas de negocio                    │
│                                                              │
│  ROUND                                                       │
│  ├─ Función: Redondeo exacto                                 │
│  ├─ Uso: F4 (precio final)                                   │
│  └─ Ventaja: Evita errores decimales en dinero               │
│                                                              │
│  SUM, AVERAGE, MAX, MIN                                      │
│  ├─ Función: Estadística básica                              │
│  ├─ Uso: B13:B17 (análisis)                                  │
│  └─ Ventaja: Comprensión rápida de datos                     │
│                                                              │
└──────────────────────────────────────────────────────────────┘
```

---

## POSIBLES ERRORES (VISUAL)

```
PROBLEMA                      SÍNTOMA              SOLUCIÓN
────────────────────────────  ──────────────────  ─────────────────────
VLOOKUP no funciona          B4 = #NAME?         Tabla no nombrada
                             B4 = #N/A           Código no existe

SUMPRODUCT incorrecto        D4 muy bajo/alto    Paréntesis mal
                             D4 = 0              Referencia incorrecta

IF muestra número            E4 = 10 (no 10%)    Formato no aplicado
en lugar de %

ROUND sin 2 decimales        F4 = 945 (no 945.00) ROUND falta parámetro
                                                  o formato error

Gráfico vacío                Sin datos            Rango A3:B8 incorrecto

Tabla dinámica               F9 ≠ 40              SUM fórmulas incompletas
no suma bien

TOTAL VS ESPERADO:
Si números no coinciden exactamente: NORMAL (datos aleatorios)
Si fórmulas están correctas: ✓ APROBADO
```

---

## TIEMPO VISUAL

```
TAREA                          MINUTOS    DIFICULTAD
─────────────────────────────  ─────────  ───────────────
1. VLOOKUP (B4:C7)             10 min     ★ Fácil
2. SUMPRODUCT (D4:D7)          8 min      ★★ Medio
3. IF Anidado (E4:E7)          7 min      ★★ Medio
4. ROUND (F4:F7)               5 min      ★ Fácil
5. Estadísticas (B13:B17)      10 min     ★★ Medio
6. Ventas Región (B20:B23)     7 min      ★★ Medio
7. Tabla Dinámica (A3:F9)      25 min     ★★★ Difícil
8. Gráfico                     12 min     ★★ Medio
9. Formatos & Impresión        15 min     ★ Fácil
─────────────────────────────────────────────────────
TOTAL:                         99 min     ★★ INTERMEDIO
```

---

**Generado:** Junio 2025  
**Curso:** CAIB Auxiliar Administrativo  
**Estudiante:** María  
**Instructor:** Guillem

