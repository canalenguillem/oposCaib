# SUPUESTO DE REPASO INTEGRAL: EXCEL

## Análisis de Ventas Electrónica Mensual

**Objetivo:** Consolidar todos los conceptos de Excel trabajados en la temporada (VLOOKUP, IF anidado, SUMPRODUCT, ROUND, condicionales, gráficos, tablas dinámicas).

**Duración estimada:** 90-120 minutos

**Nivel:** Intermedio-Avanzado

---

## DESCRIPCIÓN DEL EJERCICIO

Eres analista de datos en una empresa distribuidora de componentes informáticos. Debes procesar las ventas del mes de junio 2025 y generar un informe completo con análisis por producto y región.

**Base de datos:**
- HOJA 1: Catálogo de productos (8 productos: monitores, periféricos, componentes, accesorios)
- HOJA 2: Ventas diarias (40 transacciones registradas)
- HOJA 3: Análisis de resultados (para completar)
- HOJA 4: Tabla dinámica de resumen (para crear)

---

## APARTADO 1: ANÁLISIS DE VENTAS POR PRODUCTO

### Tarea 1.1 – VLOOKUP: Descripción del Producto

**Celda:** B4:B7

**Instrucción:**

Usar VLOOKUP para recuperar la descripción de cada producto desde la tabla TABLA_PRODUCTOS basándose en el código de producto (columna A).

**Resultado esperado:**
```
P001 → Monitor LED 24"
P003 → Ratón Inalámbrico
P005 → SSD 500GB
P007 → Memoria RAM 16GB
```

**Fórmula modelo:**

    =VLOOKUP(A4,TABLA_PRODUCTOS,2,0)

### Tarea 1.2 – VLOOKUP: Precio Unitario

**Celda:** C4:C7

**Instrucción:**

Usar VLOOKUP para obtener el precio unitario de cada producto. Formatear como moneda con 2 decimales.

**Resultado esperado:**
```
P001 → 150,00 €
P003 → 35,00 €
P005 → 55,00 €
P007 → 95,00 €
```

**Formato:** "€ "#.##0,00

### Tarea 1.3 – SUMPRODUCT: Total Vendido

**Celda:** D4:D7

**Instrucción:**

Calcular el total de ventas para cada producto multiplicando:
- La cantidad total vendida del producto (suma de TABLA_VENTAS[CANTIDAD] donde CÓDIGO_PRODUCTO = A4)
- El precio unitario (C4)

Usar SUMPRODUCT para evitar cálculos parciales.

**Fórmula modelo:**

    =SUMPRODUCT((TABLA_VENTAS[CÓDIGO_PRODUCTO]=A4)*(TABLA_VENTAS[CANTIDAD]))*C4

**Resultado esperado (aproximado):**
```
P001: 1.050,00 € (7 unidades × 150€)
P003: 665,00 € (19 unidades × 35€)
P005: 935,00 € (17 unidades × 55€)
P007: 1.235,00 € (13 unidades × 95€)
```

### Tarea 1.4 – IF Anidado: Cálculo de Descuento

**Celda:** E4:E7

**Instrucción:**

Aplicar descuento según el total de ventas del producto:
- Más de 500€ → 10% de descuento
- Más de 250€ (pero ≤ 500€) → 5% de descuento
- Hasta 250€ → Sin descuento (0%)

**Fórmula modelo:**

    =IF(D4>500,10,IF(D4>250,5,0))

**Resultado esperado:**
```
P001: 10% (1050€ > 500€)
P003: 10% (665€ > 500€)
P005: 10% (935€ > 500€)
P007: 10% (1235€ > 500€)
```

### Tarea 1.5 – ROUND: Precio Final con Descuento

**Celda:** F4:F7

**Instrucción:**

Calcular el precio final después de aplicar el descuento. Usar ROUND para redondear a 2 decimales.

**Fórmula modelo:**

    =ROUND(D4*(1-E4/100),2)

**Resultado esperado:**
```
P001: 945,00 € (1050 × 0.9)
P003: 598,50 € (665 × 0.9)
P005: 841,50 € (935 × 0.9)
P007: 1.111,50 € (1235 × 0.9)
```

**Formato:** "€ "#.##0,00

---

## APARTADO 2: ESTADÍSTICAS GENERALES

### Tarea 2.1 – SUMPRODUCT: Total de Ventas en Euros

**Celda:** B13

**Instrucción:**

Calcular el ingreso total de ventas del mes multiplicando cada venta por su precio unitario.

**Fórmula:**

    =SUMPRODUCT((TABLA_VENTAS[CANTIDAD])*VLOOKUP(TABLA_VENTAS[CÓDIGO_PRODUCTO],TABLA_PRODUCTOS,4,0))

**Resultado esperado:** Aproximadamente 8.500 – 9.000 €

### Tarea 2.2 – COUNTA: Número de Transacciones

**Celda:** B14

**Instrucción:**

Contar el número total de registros de venta en TABLA_VENTAS.

**Fórmula:**

    =COUNTA(TABLA_VENTAS[CANTIDAD])

**Resultado esperado:** 40 transacciones

### Tarea 2.3 – AVERAGE: Cantidad Promedio por Venta

**Celda:** B15

**Instrucción:**

Calcular la media de unidades vendidas por transacción.

**Fórmula:**

    =AVERAGE(TABLA_VENTAS[CANTIDAD])

**Resultado esperado:** Aproximadamente 4,5 unidades

### Tarea 2.4 – MAX y MIN: Extremos de Cantidad

**Celda:** B16 y B17

**Instrucción:**

Identificar la venta más grande y más pequeña.

**Fórmulas:**

    B16: =MAX(TABLA_VENTAS[CANTIDAD])
    B17: =MIN(TABLA_VENTAS[CANTIDAD])

**Resultado esperado:**
```
Máximo: 10 unidades
Mínimo: 1 unidad
```

### Tarea 2.5 – SUMPRODUCT: Ventas por Región

**Celda:** B20:B23

**Instrucción:**

Calcular el total de unidades vendidas por cada región usando SUMPRODUCT.

**Fórmula modelo (B20):**

    =SUMPRODUCT((TABLA_VENTAS[REGIÓN]=A20)*(TABLA_VENTAS[CANTIDAD]))

**Regiones:**
```
A20: Islas Baleares
A21: Cataluña
A22: Valencia
A23: Andalucía
```

**Resultado esperado (aproximado):**
```
Islas Baleares: ~10-12 unidades
Cataluña: ~10-12 unidades
Valencia: ~8-10 unidades
Andalucía: ~8-10 unidades
```

---

## APARTADO 3: TABLA DE RESUMEN (TABLA DINÁMICA)

### Tarea 3.1 – Crear Tabla Dinámica Manual

**Hoja:** TABLA_DINÁMICA

**Instrucción:**

Crear una tabla de resumen que cruce VENDEDORES (filas) × REGIONES (columnas) con SUMPRODUCT.

**Estructura:**

```
VENDEDOR          | Islas Baleares | Cataluña | Valencia | Andalucía | Total
─────────────────────────────────────────────────────────────────────────
Juan              |      ?         |    ?     |    ?     |    ?      |  ?
María             |      ?         |    ?     |    ?     |    ?      |  ?
Carlos            |      ?         |    ?     |    ?     |    ?      |  ?
Ana               |      ?         |    ?     |    ?     |    ?      |  ?
Roberto           |      ?         |    ?     |    ?     |    ?      |  ?
─────────────────────────────────────────────────────────────────────────
TOTAL             |      ?         |    ?     |    ?     |    ?      |  ?
```

**Fórmula para B4 (Juan - Islas Baleares):**

    =SUMPRODUCT((TABLA_VENTAS[VENDEDOR]=A4)*(TABLA_VENTAS[REGIÓN]="Islas Baleares")*(TABLA_VENTAS[CANTIDAD]))

**Replicar** para todos los vendedores y regiones.

**Formato:**
- Encabezados: Azul oscuro (5B9BD5), fuente blanca, centrado
- Fila de totales: Gris claro (D9E1F2), fuente negrita
- Números: Sin decimales, centrados

---

## APARTADO 4: GRÁFICO

### Tarea 4.1 – Crear Gráfico de Barras

**Hoja:** GRÁFICO_VENTAS

**Instrucción:**

Crear un gráfico de columnas agrupadas que muestre el total de unidades vendidas por cada vendedor.

**Datos para el gráfico:**
- Eje X: Nombres de vendedores
- Eje Y: Total de unidades (columna F de TABLA_DINÁMICA)
- Tipo: Columnas agrupadas
- Título: "Cantidad Total Vendida por Vendedor (Junio 2025)"

**Resultado esperado:**

Un gráfico que visualice claramente qué vendedor tuvo mayor volumen de ventas.

---

## APARTADO 5: FORMATOS Y ESTILOS

### Tarea 5.1 – Formatos Monetarios

**Aplicar en:**
- Columnas C, D, F (Apartado 1)
- Celda B13 (Total de ventas)

**Formato:** "€ "#.##0,00

### Tarea 5.2 – Formatos Porcentaje

**Aplicar en:**
- Columna E (Descuentos)

**Formato:** 0"%"

### Tarea 5.3 – Formatos de Tabla

**Aplicar en:**
- TABLA_PRODUCTOS: Estilo TableStyleMedium2
- TABLA_VENTAS: Estilo TableStyleMedium2
- TABLA_DINÁMICA: Encabezados azules, total gris

---

## APARTADO 6: CONFIGURACIÓN DE IMPRESIÓN

### Tarea 6.1 – Configurar Página

**En ANÁLISIS:**
- Orientación: Vertical
- Márgenes: 2 cm (superior, inferior, izquierda, derecha)
- Tamaño: A4

### Tarea 6.2 – Área de Impresión

**Área 1:** A1:F8 (Análisis de productos)

**Área 2:** A11:B23 (Estadísticas)

---

## VERIFICACIÓN FINAL

Antes de terminar, comprueba:

☐ **VLOOKUP:** Las descripciones y precios se cargan correctamente desde TABLA_PRODUCTOS

☐ **Cálculos:** Los totales vendidos (D4:D7) coinciden con las cantidades × precios

☐ **IF Anidado:** Los descuentos son 10%, 5% o 0% según reglas

☐ **ROUND:** Los precios finales tienen exactamente 2 decimales

☐ **SUMPRODUCT:** Las estadísticas (total ventas, promedio, etc.) son coherentes

☐ **Tabla Dinámica:** Vendedores × Regiones suman correctamente

☐ **Gráfico:** Muestra visualmente los datos vendidos por vendedor

☐ **Formatos:** Moneda, porcentajes y tablas se ven profesionales

☐ **Impresión:** El área de impresión está bien delimitada

---

## NOTAS IMPORTANTES

**No memorizar — Entender:**

La verdadera prueba de maestría en este supuesto no es memorizar dónde va cada fórmula, sino:
1. Entender **por qué** se usa VLOOKUP (buscar, no copiar)
2. Entender **por qué** IF anidado (cascada lógica)
3. Entender **por qué** SUMPRODUCT (condiciones múltiples)
4. Entender **cómo** ROUND evita errores decimales en dinero

Si cometes un error, pregúntate: *¿Qué información necesito?* *¿Qué función la proporciona?*

---

**Archivos de trabajo:**

- `supuesto_repaso_excel_BASE.xlsx` — Archivo para completar
- `supuesto_repaso_excel_RESUELTO.xlsx` — Solución de referencia
- `SUPUESTO_REPASO_Paso_a_Paso.md` — Guía detallada paso a paso
- `SUPUESTO_REPASO_Referencia_Rápida.md` — Fórmulas y valores esperados
- `SUPUESTO_REPASO_Resumen_Visual.md` — Diagramas y estructura visual

