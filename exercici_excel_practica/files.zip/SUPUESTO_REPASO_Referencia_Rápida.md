# SUPUESTO REPASO: REFERENCIA RÁPIDA

---

## APARTADO 1: ANÁLISIS DE PRODUCTOS

### Sección 1.1 – VLOOKUP: Descripción

| Celda | Fórmula | Resultado Esperado |
|-------|---------|-------------------|
| B4 | =VLOOKUP(A4,TABLA_PRODUCTOS,2,0) | Monitor LED 24" |
| B5 | =VLOOKUP(A5,TABLA_PRODUCTOS,2,0) | Ratón Inalámbrico |
| B6 | =VLOOKUP(A6,TABLA_PRODUCTOS,2,0) | SSD 500GB |
| B7 | =VLOOKUP(A7,TABLA_PRODUCTOS,2,0) | Memoria RAM 16GB |

**Formato:** Texto (sin formato especial)

---

### Sección 1.2 – VLOOKUP: Precio Unitario

| Celda | Fórmula | Resultado Esperado | Formato |
|-------|---------|-------------------|---------|
| C4 | =VLOOKUP(A4,TABLA_PRODUCTOS,4,0) | 150,00 € | "€ "#.##0,00 |
| C5 | =VLOOKUP(A5,TABLA_PRODUCTOS,4,0) | 35,00 € | "€ "#.##0,00 |
| C6 | =VLOOKUP(A6,TABLA_PRODUCTOS,4,0) | 55,00 € | "€ "#.##0,00 |
| C7 | =VLOOKUP(A7,TABLA_PRODUCTOS,4,0) | 95,00 € | "€ "#.##0,00 |

**Nota:** Estos valores son fijos (vienen de TABLA_PRODUCTOS).

---

### Sección 1.3 – SUMPRODUCT: Total Vendido

| Celda | Fórmula | Resultado Esperado | Formato |
|-------|---------|-------------------|---------|
| D4 | =SUMPRODUCT((TABLA_VENTAS[CÓDIGO_PRODUCTO]=A4)*(TABLA_VENTAS[CANTIDAD]))*C4 | ~1.050,00 € | "€ "#.##0,00 |
| D5 | =SUMPRODUCT((TABLA_VENTAS[CÓDIGO_PRODUCTO]=A5)*(TABLA_VENTAS[CANTIDAD]))*C5 | ~665,00 € | "€ "#.##0,00 |
| D6 | =SUMPRODUCT((TABLA_VENTAS[CÓDIGO_PRODUCTO]=A6)*(TABLA_VENTAS[CANTIDAD]))*C6 | ~935,00 € | "€ "#.##0,00 |
| D7 | =SUMPRODUCT((TABLA_VENTAS[CÓDIGO_PRODUCTO]=A7)*(TABLA_VENTAS[CANTIDAD]))*C7 | ~1.235,00 € | "€ "#.##0,00 |

**Nota:** Los valores varían según datos aleatorios. Rango aproximado: 600-1500€ cada uno.

---

### Sección 1.4 – IF Anidado: Descuento

| Celda | Fórmula | Condición | Resultado Esperado | Formato |
|-------|---------|-----------|-------------------|---------|
| E4 | =IF(D4>500,10,IF(D4>250,5,0)) | D4 > 500 | 10 % | 0"%" |
| E5 | =IF(D5>500,10,IF(D5>250,5,0)) | D5 > 500 | 10 % | 0"%" |
| E6 | =IF(D6>500,10,IF(D6>250,5,0)) | D6 > 500 | 10 % | 0"%" |
| E7 | =IF(D7>500,10,IF(D7>250,5,0)) | D7 > 500 | 10 % | 0"%" |

**Lógica:**
- Si Total > 500€ → 10% descuento
- Si Total > 250€ (pero ≤ 500€) → 5% descuento
- Si Total ≤ 250€ → 0% descuento

---

### Sección 1.5 – ROUND: Precio Final

| Celda | Fórmula | Cálculo | Resultado Esperado | Formato |
|-------|---------|---------|-------------------|---------|
| F4 | =ROUND(D4*(1-E4/100),2) | 1050 × (1 - 0,1) | 945,00 € | "€ "#.##0,00 |
| F5 | =ROUND(D5*(1-E5/100),2) | 665 × (1 - 0,1) | 598,50 € | "€ "#.##0,00 |
| F6 | =ROUND(D6*(1-E6/100),2) | 935 × (1 - 0,1) | 841,50 € | "€ "#.##0,00 |
| F7 | =ROUND(D7*(1-E7/100),2) | 1235 × (1 - 0,1) | 1.111,50 € | "€ "#.##0,00 |

**Nota:** ROUND(x, 2) redondea a 2 decimales (esencial para dinero).

---

## APARTADO 2: ESTADÍSTICAS

### Sección 2.1 – Total de Ventas (SUMPRODUCT)

| Celda | Fórmula | Resultado Esperado | Formato |
|-------|---------|-------------------|---------|
| B13 | =SUMPRODUCT((TABLA_VENTAS[CANTIDAD])*VLOOKUP(TABLA_VENTAS[CÓDIGO_PRODUCTO],TABLA_PRODUCTOS,4,0)) | 8.500 – 9.000 € | "€ "#.##0,00 |

**Significado:** Ingreso total (todas las ventas × sus precios).

---

### Sección 2.2 – Transacciones (COUNTA)

| Celda | Fórmula | Resultado Esperado | Notas |
|-------|---------|-------------------|-------|
| B14 | =COUNTA(TABLA_VENTAS[CANTIDAD]) | 40 | Número fijo de registros |

**Significado:** Cuántas compras se registraron en total.

---

### Sección 2.3 – Promedio (AVERAGE)

| Celda | Fórmula | Resultado Esperado | Formato |
|-------|---------|-------------------|---------|
| B15 | =AVERAGE(TABLA_VENTAS[CANTIDAD]) | 4,5 – 5,0 unidades | Número con 2 decimales |

**Significado:** Media de unidades vendidas por transacción.

---

### Sección 2.4 – Máximo y Mínimo

| Celda | Fórmula | Resultado Esperado | Notas |
|-------|---------|-------------------|-------|
| B16 | =MAX(TABLA_VENTAS[CANTIDAD]) | 10 | Venta más grande |
| B17 | =MIN(TABLA_VENTAS[CANTIDAD]) | 1 | Venta más pequeña |

---

### Sección 2.5 – Ventas por Región (SUMPRODUCT)

| Celda | Región | Fórmula | Resultado Esperado | Formato |
|-------|--------|---------|-------------------|---------|
| B20 | Islas Baleares | =SUMPRODUCT((TABLA_VENTAS[REGIÓN]=A20)*(TABLA_VENTAS[CANTIDAD])) | 8 – 12 | Número entero |
| B21 | Cataluña | =SUMPRODUCT((TABLA_VENTAS[REGIÓN]=A21)*(TABLA_VENTAS[CANTIDAD])) | 8 – 12 | Número entero |
| B22 | Valencia | =SUMPRODUCT((TABLA_VENTAS[REGIÓN]=A22)*(TABLA_VENTAS[CANTIDAD])) | 8 – 12 | Número entero |
| B23 | Andalucía | =SUMPRODUCT((TABLA_VENTAS[REGIÓN]=A23)*(TABLA_VENTAS[CANTIDAD])) | 8 – 12 | Número entero |

**Total:** 40 unidades (suma de todas las regiones)

---

## APARTADO 3: TABLA DINÁMICA

### Estructura Base

```
Fila 3: Encabezados
        A3: VENDEDOR | B3: Islas Baleares | C3: Cataluña | D3: Valencia | E3: Andalucía | F3: Total

Filas 4-8: Vendedores
        A4: Juan | A5: María | A6: Carlos | A7: Ana | A8: Roberto

Fila 9: Total
        A9: TOTAL
```

### Fórmulas SUMPRODUCT

**Juan - Islas Baleares (B4):**

    =SUMPRODUCT((TABLA_VENTAS[VENDEDOR]=A4)*(TABLA_VENTAS[REGIÓN]="Islas Baleares")*(TABLA_VENTAS[CANTIDAD]))

**Copiar y adaptar para cada región:**

    C4: =SUMPRODUCT((TABLA_VENTAS[VENDEDOR]=A4)*(TABLA_VENTAS[REGIÓN]="Cataluña")*(TABLA_VENTAS[CANTIDAD]))
    D4: =SUMPRODUCT((TABLA_VENTAS[VENDEDOR]=A4)*(TABLA_VENTAS[REGIÓN]="Valencia")*(TABLA_VENTAS[CANTIDAD]))
    E4: =SUMPRODUCT((TABLA_VENTAS[VENDEDOR]=A4)*(TABLA_VENTAS[REGIÓN]="Andalucía")*(TABLA_VENTAS[CANTIDAD]))

**Totales por vendedor (F4):**

    F4: =SUM(B4:E4)

**Copiar B4:F4 hacia abajo para filas 5-8** (se ajustan automáticamente)

**Fila Total (fila 9):**

    B9: =SUM(B4:B8)
    C9: =SUM(C4:C8)
    D9: =SUM(D4:D8)
    E9: =SUM(E4:E8)
    F9: =SUM(F4:F8)

### Resultado Esperado (Aproximado)

```
VENDEDOR     | Islas Baleares | Cataluña | Valencia | Andalucía | Total
─────────────────────────────────────────────────────────────────────────
Juan         |      2-3       |   2-3    |   2-3    |   2-3     |   8-10
María        |      2-3       |   2-3    |   2-3    |   2-3     |   8-10
Carlos       |      2-3       |   2-3    |   2-3    |   2-3     |   8-10
Ana          |      2-3       |   2-3    |   2-3    |   2-3     |   8-10
Roberto      |      2-3       |   2-3    |   2-3    |   2-3     |   8-10
─────────────────────────────────────────────────────────────────────────
TOTAL        |      10-15     |  10-15   |  10-15   |  10-15    |   40
```

**Formato:**
- Encabezados (A3:F3): Color fondo 5B9BD5 (azul), texto blanco, centrado
- Totales (A9:F9): Color fondo D9E1F2 (gris), texto negrita
- Números: Centrados, sin decimales

---

## APARTADO 4: GRÁFICO

### Tipo: Columnas Agrupadas

| Propiedad | Valor |
|-----------|-------|
| Tipo | Gráfico de columnas agrupadas |
| Datos fuente | Hoja GRÁFICO_VENTAS, A3:B8 |
| Eje X (Categorías) | Nombres de vendedores |
| Eje Y (Valores) | Total de unidades (F4:F8 de TABLA_DINÁMICA) |
| Título | "Cantidad Total Vendida por Vendedor (Junio 2025)" |
| Eje X Label | "Vendedor" |
| Eje Y Label | "Cantidad (unidades)" |

### Datos para Gráfico (GRÁFICO_VENTAS)

| A (Vendedor) | B (Cantidad) | Fórmula |
|--------------|-------------|---------|
| Juan | ~9 | =TABLA_DINÁMICA!F4 |
| María | ~9 | =TABLA_DINÁMICA!F5 |
| Carlos | ~9 | =TABLA_DINÁMICA!F6 |
| Ana | ~9 | =TABLA_DINÁMICA!F7 |
| Roberto | ~9 | =TABLA_DINÁMICA!F8 |

---

## APARTADO 5: FORMATOS

### Formatos Monetarios

**Rango:** C4:C7, D4:D7, F4:F7, B13

**Formato:**

    "€ "#.##0,00

**Desglose:**
- "€ " = Símbolo € con espacio
- # = Dígito opcional
- .##0 = Separador de miles (puede omitirse si < 1.000)
- ,00 = Coma como separador decimal, 2 decimales obligatorios

**Resultado visual:**
```
100 → € 100,00
1050 → € 1.050,00
0,1 → € 0,10
```

---

### Formatos Porcentaje

**Rango:** E4:E7

**Formato:**

    0"%"

**Desglose:**
- 0 = Número sin decimales
- "%"  = Símbolo % literal (no conversión automática)

**Resultado visual:**
```
10 → 10%
5 → 5%
0 → 0%
```

---

### Formatos Número (Decimales)

**Rango:** B15 (promedio)

**Formato:**

    0.00

**Resultado visual:**
```
4.5 → 4,50
5.0 → 5,00
```

---

## APARTADO 6: CONFIGURACIÓN IMPRESIÓN

### Márgenes

| Posición | Valor |
|----------|-------|
| Superior | 2 cm |
| Inferior | 2 cm |
| Izquierda | 2 cm |
| Derecha | 2 cm |

### Página

| Propiedad | Valor |
|-----------|-------|
| Tamaño | A4 (210 × 297 mm) |
| Orientación | Vertical |

---

## CHECKLIST DE VERIFICACIÓN

### Paso 1: Fórmulas

    ☐ B4:B7 tienen VLOOKUP funcionando
    ☐ C4:C7 tienen VLOOKUP de precios
    ☐ D4:D7 tienen SUMPRODUCT × precio
    ☐ E4:E7 tienen IF anidado con descuentos
    ☐ F4:F7 tienen ROUND a 2 decimales
    ☐ B13 tiene SUMPRODUCT total
    ☐ B14 tiene COUNTA = 40
    ☐ B15 tiene AVERAGE
    ☐ B16 tiene MAX = 10
    ☐ B17 tiene MIN = 1
    ☐ B20:B23 tienen SUMPRODUCT por región
    ☐ TABLA_DINÁMICA tiene SUMPRODUCT en B4:E8
    ☐ Fila total (9) tiene SUM en cada columna
    ☐ Gráfico existe con datos de GRÁFICO_VENTAS

### Paso 2: Formatos

    ☐ Moneda €: C4:C7, D4:D7, F4:F7, B13
    ☐ Porcentaje %: E4:E7
    ☐ Tabla dinámica encabezados: azul (5B9BD5)
    ☐ Tabla dinámica total: gris (D9E1F2)
    ☐ Gráfico tiene título

### Paso 3: Valores Razonables

    ☐ Precios son positivos
    ☐ Descuentos son 0%, 5%, o 10%
    ☐ Precios finales < Precios originales (por descuento)
    ☐ Total de ventas > 8.000€
    ☐ Tabla dinámica suma 40 en F9
    ☐ Cada región suma ~10 en fila 9

---

## VALORES ESPERADOS (RESUMIDO)

| Elemento | Valor |
|----------|-------|
| Total Ventas (B13) | 8.500 – 9.000 € |
| Transacciones (B14) | 40 |
| Promedio (B15) | 4,5 – 5,0 |
| Máximo (B16) | 10 |
| Mínimo (B17) | 1 |
| Suma Regional (B20:B23) | 40 |
| Tabla Dinámica Total (F9) | 40 |
| Gráfico (5 barras) | ~8-10 cada una |

---

## REFERENCIAS TÉCNICAS

### Tablas Formales Requeridas

    TABLA_PRODUCTOS (PRODUCTOS)
    - Rango: A1:E9
    - Encabezado: Código, Descripción, Categoría, Precio_Unitario, Stock

    TABLA_VENTAS (VENTAS_DIARIAS)
    - Rango: A1:E41
    - Encabezado: Fecha, Código_Producto, Cantidad, Vendedor, Región

### Funciones Utilizadas

| Función | Uso |
|---------|-----|
| VLOOKUP | Búsqueda exacta en tabla |
| SUMPRODUCT | Suma con múltiples condiciones |
| IF | Lógica condicional |
| ROUND | Redondeo a decimales |
| COUNTA | Contar celdas con contenido |
| AVERAGE | Promedio |
| MAX | Máximo |
| MIN | Mínimo |
| SUM | Suma simple |

---

## NOTAS PEDAGÓGICAS

**¿Por qué estas funciones?**

1. **VLOOKUP**: Para NO escribir datos manualmente → automatización
2. **SUMPRODUCT**: Para contar/sumar con condiciones → análisis flexible
3. **IF anidado**: Para lógica de negocio (descuentos) → toma de decisiones
4. **ROUND**: Para evitar errores decimales en dinero → exactitud financiera
5. **Tabla dinámica**: Para ver datos desde distintos ángulos → análisis multidimensional
6. **Gráfico**: Para comunicar visualmente → presentación clara

**Conexión con examen CAIB:**

Estas funciones son básicas en la oposición. Un supuesto real probablemente:
- Pida buscar datos (VLOOKUP o ÍNDICE-COINCIDIR)
- Requiera cálculos condicionales (IF anidado, SUMPRODUCT)
- Incluya gráfico para resumen
- Demande precisión en formatos

---

**Última actualización:** Junio 2025  
**Curso:** CAIB Auxiliar Administrativo  
**Estudiante:** María

