# SUPUESTO REPASO INTEGRAL: PASO A PASO

Estudiante: María  
Instructor: Guillem  
Duración estimada: 90-120 minutos

---

## ANTES DE EMPEZAR

1. Descarga el archivo: **supuesto_repaso_excel_BASE.xlsx**
2. Guarda una copia como: **TU_NOMBRE_supuesto_repaso.xlsx**
3. Abre Excel 2021 y carga el archivo
4. Ten a mano el archivo RESUELTO como referencia (solo para verificar, no para copiar)

---

## APARTADO 1: ANÁLISIS DE VENTAS POR PRODUCTO

### TAREA 1.1: VLOOKUP – Descripción del Producto

**Objetivo:** Traer automáticamente el nombre del producto basándose en su código.

**Pasos:**

1. Abre la hoja **ANÁLISIS**

2. Haz clic en la celda **B4** (fila con código P001)

3. Escribe la fórmula:

       =VLOOKUP(A4,TABLA_PRODUCTOS,2,0)

4. Presiona **Enter**

5. En B4 debe aparecer: **"Monitor LED 24""**

6. Copia la fórmula a las celdas **B5**, **B6**, **B7**

   - Selecciona B4
   - Copia (Ctrl+C)
   - Selecciona B5:B7
   - Pega (Ctrl+V)

7. Verifica los resultados:

       B4: Monitor LED 24"
       B5: Ratón Inalámbrico
       B6: SSD 500GB
       B7: Memoria RAM 16GB

**Explicación de la fórmula:**

    =VLOOKUP(A4, TABLA_PRODUCTOS, 2, 0)
                    ↓                  ↓  ↓
                  Dónde buscar    Columna Exacto
    
    A4 = "P001"
    TABLA_PRODUCTOS = Tabla con productos (columnas: Código, Descripción, Categoría, Precio, Stock)
    2 = Devuelve valor de la 2ª columna (Descripción)
    0 = Búsqueda exacta

---

### TAREA 1.2: VLOOKUP – Precio Unitario

**Objetivo:** Obtener el precio de cada producto.

**Pasos:**

1. Haz clic en la celda **C4**

2. Escribe la fórmula:

       =VLOOKUP(A4,TABLA_PRODUCTOS,4,0)

3. Presiona **Enter**

4. En C4 debe aparecer: **150** (sin formato aún)

5. Copia la fórmula a **C5:C7**

   - Selecciona C4
   - Copia (Ctrl+C)
   - Selecciona C5:C7
   - Pega (Ctrl+V)

6. Ahora **formatea como moneda**:

   - Selecciona el rango **C4:C7**
   - Botón derecho > Formato de celda
   - Pestaña **Números**
   - Categoría: **Moneda**
   - Formato: **"€ "#.##0,00**
   - Aceptar

7. Los valores deben mostrar:

       C4: € 150,00
       C5: € 35,00
       C6: € 55,00
       C7: € 95,00

**¿Por qué columna 4?**

La tabla TABLA_PRODUCTOS tiene: Código (1), Descripción (2), Categoría (3), **Precio (4)**, Stock (5)

---

### TAREA 1.3: SUMPRODUCT – Total Vendido

**Objetivo:** Calcular cuánto dinero se ganó con cada producto (cantidad × precio).

**Pasos:**

1. Haz clic en la celda **D4**

2. Escribe la fórmula:

       =SUMPRODUCT((TABLA_VENTAS[CÓDIGO_PRODUCTO]=A4)*(TABLA_VENTAS[CANTIDAD]))*C4

3. Presiona **Enter**

4. En D4 debe aparecer un número (ej: 1050)

5. Copia la fórmula a **D5:D7**

   - Selecciona D4
   - Copia (Ctrl+C)
   - Selecciona D5:D7
   - Pega (Ctrl+V)

6. **Formatea como moneda** (igual que C4:C7):

   - Selecciona **D4:D7**
   - Botón derecho > Formato de celda
   - Categoría: Moneda
   - Formato: "€ "#.##0,00
   - Aceptar

7. Los valores deben mostrar aproximadamente:

       D4: € 1.050,00
       D5: € 665,00
       D6: € 935,00
       D7: € 1.235,00

**¿Cómo funciona SUMPRODUCT?**

    =SUMPRODUCT((TABLA_VENTAS[CÓDIGO_PRODUCTO]=A4) * (TABLA_VENTAS[CANTIDAD])) * C4
    
    Paso 1: (TABLA_VENTAS[CÓDIGO_PRODUCTO]=A4)
            → Busca todas las filas donde el código es P001
            → Devuelve: VERDADERO, VERDADERO, VERDADERO... FALSO, FALSO...
    
    Paso 2: Multiplica por CANTIDAD
            → 1×1, 1×1, 1×1... 0×5, 0×3...
            → Solo suma las cantidades de P001
    
    Paso 3: Multiplica por C4 (precio)
            → Total de P001 = 7 unidades × 150€

**Nota:** Si los números no cuadran exactamente, es porque las ventas son aleatorias en tu archivo base. Eso es normal.

---

### TAREA 1.4: IF Anidado – Cálculo de Descuento

**Objetivo:** Asignar descuento según el total de ventas del producto.

**Regla de descuento:**
- Total > 500€ → 10% de descuento
- Total > 250€ (pero ≤ 500€) → 5% de descuento
- Total ≤ 250€ → Sin descuento (0%)

**Pasos:**

1. Haz clic en la celda **E4**

2. Escribe la fórmula:

       =IF(D4>500,10,IF(D4>250,5,0))

3. Presiona **Enter**

4. En E4 debe aparecer: **10** (porque D4 es mayor a 500)

5. Copia la fórmula a **E5:E7**

   - Selecciona E4
   - Copia (Ctrl+C)
   - Selecciona E5:E7
   - Pega (Ctrl+V)

6. **Formatea como porcentaje**:

   - Selecciona **E4:E7**
   - Botón derecho > Formato de celda
   - Categoría: **Personalizado**
   - Formato: **0"%"**
   - Aceptar

7. Los valores deben mostrar:

       E4: 10%
       E5: 10%
       E6: 10%
       E7: 10%

**Lectura de la fórmula:**

    =IF(D4>500, 10, IF(D4>250, 5, 0))
            ↓           ↓             ↓
      ¿Es > 500?  Sí: Devuelve 10  Si no, continúa...
      
    Si D4 ≤ 500:
    =IF(D4>250, 5, 0)
            ↓       ↓
      ¿Es > 250?  Sí: 5, Si no: 0

---

### TAREA 1.5: ROUND – Precio Final con Descuento

**Objetivo:** Calcular el precio después de aplicar el descuento (redondeado a 2 decimales).

**Pasos:**

1. Haz clic en la celda **F4**

2. Escribe la fórmula:

       =ROUND(D4*(1-E4/100),2)

3. Presiona **Enter**

4. En F4 debe aparecer aproximadamente: **945** (1050 × 0.9)

5. Copia la fórmula a **F5:F7**

   - Selecciona F4
   - Copia (Ctrl+C)
   - Selecciona F5:F7
   - Pega (Ctrl+V)

6. **Formatea como moneda**:

   - Selecciona **F4:F7**
   - Botón derecho > Formato de celda
   - Categoría: Moneda
   - Formato: "€ "#.##0,00
   - Aceptar

7. Los valores deben mostrar:

       F4: € 945,00
       F5: € 598,50
       F6: € 841,50
       F7: € 1.111,50

**¿Cómo funciona ROUND?**

    =ROUND(D4*(1-E4/100), 2)
           ↓          ↓      ↓
         Valor   Descuento Decimales

    D4 = 1050
    E4 = 10 (%)
    
    (1-E4/100) = 1 - 0.1 = 0.9
    D4 * 0.9 = 1050 * 0.9 = 945.00000...
    
    ROUND(..., 2) → Redondea a 2 decimales → 945.00

**¿Por qué ROUND es importante?**

Sin ROUND podrías obtener € 945.00000001 (errores de cálculo). ROUND garantiza exactitud en dinero.

---

## APARTADO 2: ESTADÍSTICAS GENERALES

### TAREA 2.1: Total de Ventas (SUMPRODUCT)

**Objetivo:** Calcular el ingreso total del mes.

**Pasos:**

1. Haz clic en la celda **B13**

2. Escribe la fórmula:

       =SUMPRODUCT((TABLA_VENTAS[CANTIDAD])*VLOOKUP(TABLA_VENTAS[CÓDIGO_PRODUCTO],TABLA_PRODUCTOS,4,0))

3. Presiona **Enter**

4. Debe aparecer un número grande (ej: 8500)

5. **Formatea como moneda**:

   - Selecciona B13
   - Botón derecho > Formato de celda
   - Categoría: Moneda
   - Formato: "€ "#.##0,00
   - Aceptar

6. Resultado aproximado: **€ 8.500,00 a € 9.000,00**

**¿Cómo funciona?**

    SUMPRODUCT(
      (TABLA_VENTAS[CANTIDAD])         ← Todas las cantidades
      *
      VLOOKUP(TABLA_VENTAS[CÓDIGO_PRODUCTO], TABLA_PRODUCTOS, 4, 0)
                                       ← Precio de cada producto vendido
    )
    
    Suma: (5 unidades × 150€) + (3 × 35€) + (7 × 55€) + ...

---

### TAREA 2.2: Número de Transacciones (COUNTA)

**Objetivo:** Contar cuántas ventas se registraron.

**Pasos:**

1. Haz clic en la celda **B14**

2. Escribe la fórmula:

       =COUNTA(TABLA_VENTAS[CANTIDAD])

3. Presiona **Enter**

4. Debe aparecer: **40** (número total de transacciones)

5. Sin necesidad de formato (es número entero)

---

### TAREA 2.3: Promedio de Cantidad (AVERAGE)

**Objetivo:** Calcular la media de unidades por transacción.

**Pasos:**

1. Haz clic en la celda **B15**

2. Escribe la fórmula:

       =AVERAGE(TABLA_VENTAS[CANTIDAD])

3. Presiona **Enter**

4. Debe aparecer aproximadamente: **4,5** o **5**

5. **Formato**: Puede quedar con decimales. Si prefieres 2 decimales:

   - Botón derecho > Formato de celda
   - Categoría: Número
   - Decimales: 2
   - Aceptar

---

### TAREA 2.4: Máximo y Mínimo (MAX / MIN)

**Objetivo:** Identificar la venta más grande y más pequeña.

**Pasos para B16 (Máximo):**

1. Haz clic en **B16**

2. Escribe:

       =MAX(TABLA_VENTAS[CANTIDAD])

3. Presiona **Enter**

4. Debe aparecer: **10** (la venta más grande)

**Pasos para B17 (Mínimo):**

1. Haz clic en **B17**

2. Escribe:

       =MIN(TABLA_VENTAS[CANTIDAD])

3. Presiona **Enter**

4. Debe aparecer: **1** (la venta más pequeña)

---

### TAREA 2.5: Ventas por Región (SUMPRODUCT)

**Objetivo:** Calcular el total de unidades vendidas por cada región.

**Pasos:**

1. Verifica que las regiones estén en A20:A23:

       A20: Islas Baleares
       A21: Cataluña
       A22: Valencia
       A23: Andalucía

2. Haz clic en la celda **B20**

3. Escribe la fórmula:

       =SUMPRODUCT((TABLA_VENTAS[REGIÓN]=A20)*(TABLA_VENTAS[CANTIDAD]))

4. Presiona **Enter**

5. Copia la fórmula a **B21:B23**

   - Selecciona B20
   - Copia (Ctrl+C)
   - Selecciona B21:B23
   - Pega (Ctrl+V)

6. Verifica que los números tengan sentido (cada región debe sumar entre 8-12 unidades aprox.)

7. **Sin necesidad de formato monetario** (son unidades, no dinero)

---

## APARTADO 3: TABLA DE RESUMEN (TABLA DINÁMICA MANUAL)

### TAREA 3.1: Crear Tabla de Resumen por Vendedor y Región

**Objetivo:** Crear una tabla cruzada que muestre ventas por vendedor × región.

**Pasos:**

1. Ve a la hoja **TABLA_DINÁMICA**

2. Verifica la estructura:

       A3: VENDEDOR    | B3: Islas Baleares | C3: Cataluña | D3: Valencia | E3: Andalucía | F3: Total

3. Verifica los vendedores en A4:A8:

       A4: Juan
       A5: María
       A6: Carlos
       A7: Ana
       A8: Roberto

4. Haz clic en la celda **B4** (Juan - Islas Baleares)

5. Escribe la fórmula:

       =SUMPRODUCT((TABLA_VENTAS[VENDEDOR]=A4)*(TABLA_VENTAS[REGIÓN]="Islas Baleares")*(TABLA_VENTAS[CANTIDAD]))

6. Presiona **Enter**

7. Debe aparecer un número (0 a 5 unidades aprox.)

8. Ahora copia hacia la derecha a C4:E4 **con cuidado**:

   - Selecciona B4
   - Copia (Ctrl+C)
   - Selecciona C4:E4
   - Pega (Ctrl+V) → **¡OJO!** Las fórmulas NO se ajustarán automáticamente

9. **Edita cada celda manualmente**:

   - C4 (Cataluña):

         =SUMPRODUCT((TABLA_VENTAS[VENDEDOR]=A4)*(TABLA_VENTAS[REGIÓN]="Cataluña")*(TABLA_VENTAS[CANTIDAD]))

   - D4 (Valencia):

         =SUMPRODUCT((TABLA_VENTAS[VENDEDOR]=A4)*(TABLA_VENTAS[REGIÓN]="Valencia")*(TABLA_VENTAS[CANTIDAD]))

   - E4 (Andalucía):

         =SUMPRODUCT((TABLA_VENTAS[VENDEDOR]=A4)*(TABLA_VENTAS[REGIÓN]="Andalucía")*(TABLA_VENTAS[CANTIDAD]))

10. Copia F4 con la fórmula de suma:

        F4: =SUM(B4:E4)

11. Ahora **copia todas las fórmulas hacia abajo** para María (fila 5), Carlos (6), Ana (7), Roberto (8):

    - Selecciona B4:F4
    - Copia (Ctrl+C)
    - Selecciona B5:F8
    - Pega (Ctrl+V) → Aquí SÍ se ajustan automáticamente

12. Crea la fila **Total** (fila 9):

    - A9: TOTAL
    - B9: =SUM(B4:B8)
    - Copia C9:F9 (SUM de cada columna)

13. **Formatos**:

    - Encabezados (A3:F3): Azul (5B9BD5), fuente blanca, centrado
    - Fila Total (A9:F9): Gris (D9E1F2), fuente negrita
    - Todos los números: Centrados, sin decimales

**Resultado esperado (aproximado):**

```
VENDEDOR     | Islas Baleares | Cataluña | Valencia | Andalucía | Total
─────────────────────────────────────────────────────────────────────────
Juan         |      2         |    3     |    2     |    1      |   8
María        |      2         |    1     |    3     |    2      |   8
Carlos       |      2         |    2     |    1     |    3      |   8
Ana          |      2         |    2     |    2     |    2      |   8
Roberto      |      2         |    2     |    2     |    2      |   8
─────────────────────────────────────────────────────────────────────────
TOTAL        |     10         |   10     |   10     |   10      |  40
```

---

## APARTADO 4: GRÁFICO

### TAREA 4.1: Crear Gráfico de Barras

**Objetivo:** Visualizar el total de unidades vendidas por cada vendedor.

**Pasos:**

1. Ve a la hoja **GRÁFICO_VENTAS**

2. Verifica los datos:

       A3: VENDEDOR
       B3: TOTAL (unidades)
       A4:A8: Nombres de vendedores
       B4:B8: Fórmulas que traen datos de TABLA_DINÁMICA

3. Haz clic en el rango **A3:B8** (incluye encabezados)

4. Ve a **Insertar** > **Gráfico de columnas**

5. Selecciona **Columnas agrupadas** (la primera opción)

6. Se abrirá el asistente. En la pestaña **Datos**:
   - Confirma que el rango es A3:B8
   - Haz clic **Siguiente**

7. En la pestaña **Diseño**:
   - Título del gráfico: **"Cantidad Total Vendida por Vendedor (Junio 2025)"**
   - Haz clic **Siguiente**

8. En la pestaña **Ubicación**:
   - Selecciona: **"Objeto en esta hoja"**
   - Haz clic **Finalizar**

9. El gráfico aparecerá en la hoja. **Redimensiona** si es necesario:
   - Haz clic en el gráfico
   - Arrastra las esquinas para ajustar tamaño

10. **Aplicar estilos** (opcional pero recomendado):
    - Haz clic en el gráfico
    - Pestaña **Diseño** (en la cinta de herramientas)
    - Elige un estilo que te guste

**Resultado esperado:**

Un gráfico de columnas con 5 barras (una por vendedor) de altura similar (aproximadamente 8-10 unidades cada una).

---

## APARTADO 5: FORMATOS Y ESTILOS

### TAREA 5.1: Verificar Formatos Monetarios

**Dónde:** Hoja ANÁLISIS, columnas C, D, F (filas 4-7) y B13

**Verificación:**

1. Selecciona **C4:C7**
2. Botón derecho > **Formato de celda**
3. Confirma:
   - Categoría: **Moneda**
   - Formato: **"€ "#.##0,00**
   - Símbolo: € (Euro)
   - Decimales: 2
   - Aceptar

4. Repite para **D4:D7** y **F4:F7**

---

### TAREA 5.2: Verificar Formatos Porcentaje

**Dónde:** Hoja ANÁLISIS, columna E (filas 4-7)

**Verificación:**

1. Selecciona **E4:E7**
2. Botón derecho > **Formato de celda**
3. Confirma:
   - Categoría: **Personalizado**
   - Formato: **0"%"**
   - Aceptar

---

### TAREA 5.3: Tablas Formales

**Las tablas ya están creadas**, pero verifica:

- **TABLA_PRODUCTOS** (PRODUCTOS)
- **TABLA_VENTAS** (VENTAS_DIARIAS)

Ambas deben tener:
- Encabezados con estilo TableStyleMedium2 (o similar)
- Bordes definidos
- Colores alternados en filas

---

## APARTADO 6: CONFIGURACIÓN DE IMPRESIÓN

### TAREA 6.1: Configurar Márgenes

**En la hoja ANÁLISIS:**

1. Ve a **Archivo** > **Preparar para imprimir** > **Configurar página**

2. En la pestaña **Márgenes**:
   - Superior: 2 cm
   - Inferior: 2 cm
   - Izquierda: 2 cm
   - Derecha: 2 cm

3. Aceptar

### TAREA 6.2: Orientación y Tamaño

**En la misma ventana, pestaña Página:**

1. Orientación: **Vertical**

2. Tamaño: **A4**

3. Aceptar

---

## VERIFICACIÓN FINAL (CHECKLIST)

Antes de dar por terminado el ejercicio, comprueba:

**Apartado 1 (Análisis de Productos):**

☐ B4:B7 tienen descripciones (VLOOKUP)

☐ C4:C7 tienen precios con formato €

☐ D4:D7 tienen totales calculados correctamente (SUMPRODUCT × Precio)

☐ E4:E7 tienen descuentos (10%, 5%, 0%) según regla IF

☐ F4:F7 tienen precios finales con ROUND (2 decimales)

**Apartado 2 (Estadísticas):**

☐ B13: Total de ventas > 8.000€

☐ B14: 40 transacciones

☐ B15: Promedio ~4-5 unidades

☐ B16: Máximo = 10

☐ B17: Mínimo = 1

☐ B20:B23: Ventas por región suman ~40 total

**Apartado 3 (Tabla Dinámica):**

☐ Tabla 5 vendedores × 4 regiones está completa

☐ Cada celda tiene fórmula SUMPRODUCT

☐ Fila Total suma correctamente

☐ Encabezados azules, Total gris

**Apartado 4 (Gráfico):**

☐ Gráfico de columnas creado

☐ Título visible

☐ 5 columnas (una por vendedor)

**Apartado 5 (Formatos):**

☐ Moneda € en C, D, F

☐ Porcentaje % en E

☐ Tablas con estilo formal

**Apartado 6 (Impresión):**

☐ Márgenes: 2 cm en todos lados

☐ Orientación: Vertical

☐ Tamaño: A4

---

## ERRORES COMUNES Y SOLUCIONES

| Error | Causa | Solución |
|-------|-------|----------|
| B4 muestra #NAME? | TABLA_PRODUCTOS no existe | Verifica que la tabla esté formalmente creada (Ctrl+T) en PRODUCTOS |
| D4 muestra resultado inesperado | SUMPRODUCT mal escrito | Verifica paréntesis y referencias exactas |
| E4 muestra número en lugar de % | Formato no aplicado | Aplica formato Personalizado: 0"%" |
| Gráfico está vacío | Rango de datos incorrecto | Selecciona A3:B8 (con encabezados) |
| Tabla dinámica no suma bien | Fórmulas SUMPRODUCT con referencias mal | Edita cada región manualmente |
| Formato € aparece pero sin símbolo | Formato incorrecto | Usa: "€ "#.##0,00 (con comilla de apertura) |

---

## TIEMPO ESTIMADO POR APARTADO

- Apartado 1 (Análisis): 25-30 minutos
- Apartado 2 (Estadísticas): 15-20 minutos
- Apartado 3 (Tabla Dinámica): 20-25 minutos
- Apartado 4 (Gráfico): 10-15 minutos
- Apartados 5-6 (Formato e impresión): 10-15 minutos

**Total: 90-120 minutos**

---

**Preguntas frecuentes:**

**P: ¿Mis números son diferentes a los del archivo RESUELTO?**
R: Es normal. Los datos de VENTAS_DIARIAS son aleatorios. Lo importante es que las **fórmulas funcionan**, no que los números exactos coincidan.

**P: ¿Se puede hacer más rápido?**
R: Sí, si practicas atajos de teclado (Ctrl+C, Ctrl+V, F2 para editar). Pero la comprensión es más importante que la velocidad.

**P: ¿Debo memorizar estas fórmulas?**
R: No. Debes entender **cuándo usarlas y por qué**. En el examen tendrás acceso a referencia.

---

**Generado:** Junio 2025  
**Curso:** CAIB Auxiliar Administrativo  
**Instructor:** Guillem  
**Estudiante:** María

